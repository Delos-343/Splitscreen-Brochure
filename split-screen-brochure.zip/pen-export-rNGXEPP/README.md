# Split-Screen Brochure

A Pen created on CodePen.io. Original URL: [https://codepen.io/Delos_343/pen/rNGXEPP](https://codepen.io/Delos_343/pen/rNGXEPP).

